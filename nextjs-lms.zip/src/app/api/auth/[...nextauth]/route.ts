export { handlers as GET, handlers as POST } from "@/lib/auth";
